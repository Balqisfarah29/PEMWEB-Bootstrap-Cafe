<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    echo "OK";
} else {
    echo "Error: Invalid request!";
}
?>
